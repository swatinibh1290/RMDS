# This repo contains the details about our approach to using ML to predict the Equity Style Box given in the funds.csv .

1. Please install the requirements using the code
<code> pip install -r requirements.txt </code>

2. Run the notebook in  machine-learning-book.ipynb to create a Random Forest model which is capable of classifying the Equity Style Box.
   The code also produces and compares the performance of many other ML models but we found that Random Forest tuned with Bayseain Optimization search produces the best result.

   NOTE: If required change the file path to read in datafunds.csv

3. One can use a new dataset from morningstar and replicate the preprocessing steps mentioned in the notebook machine-learning-book.ipynb to get their own results.

4. In the ML-fill-missing-equityStylebox.ipynb we have shown how we can use the Random Forest model built in step 2 can be used for filling in missing values for Equity Style box in the original dataset. This also guides people in creating/using  our Model for actual inference and classification.

5. The dataset in data/new_equity_filled_fixed.csv conatins the data with all the Equity Stylebox missing data filled. This was also used to build one more Tabelu dashboard