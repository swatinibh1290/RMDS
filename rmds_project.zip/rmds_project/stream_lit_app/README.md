## How to use the repo
1. Install the dependncies by running
 <code> pip install -r requirements.txt  </code>

2. Then run the streamlit command to see the dashboard using
  <code> streamlit run stream_app.py </code>

## Once you navigate to dashboard select the funds you want to see holdings and sector distribution for.

## Limitation

If yahoo finance doesn't have the holdings and sector distribution the dashboard won't be able to show the data to you.