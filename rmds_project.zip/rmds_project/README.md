## ML_EQUITY_Style_Box has the code for Machine Learning models
## steam_lit_app has a dynamic dashboard
## data.zip has the dataset we used
## Report_RMDS.pdf contains the report and how to navigate everything we submit
## The .twbx has our Tabelu dashboard.

## Thank you for an amazing comepetion 